<?php
include('includes/paths.php');
require('includes/credentials.php');
	$reportid =$_POST['reportid'];
	
    if(isset($reportid)){
        if(!empty($reportid)){      
          try{
              $conn=new PDO(GBDSN,GBDBA,GBPWD);//use PDO objects, built in since PHP5
			  $sql="Update reports Set status ='done' Where rowid=".$reportid;
			  $stmt=$conn->prepare($sql);//statement object
	          $conn->beginTransaction();//begin transaction
              $stmt->execute();//run statement
	          $conn->commit();
			  //if($stmt->rowcount()>0){
                echo "success|";
	          //} else {
	          //  echo "failure|update";
	          //}
		  }
		  catch(Exception $e){
            if(isset($conn)){
              $conn->rollBack();
              $conn=null;
            }
			echo 'failure|exception';
          }      
        }       
    }  else {
        echo 'failure|reportid';
    }
	
	
?>