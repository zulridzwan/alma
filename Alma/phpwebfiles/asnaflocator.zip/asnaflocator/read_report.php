<?php
include('includes/paths.php');
require('includes/credentials.php');

$reportid =$_POST['reportid'];

if(isset($reportid)){
  if(!empty($reportid)){
    $sql="SELECT * FROM mapview WHERE rowid=".$reportid;  
  } else {
    $sql="SELECT * FROM mapview";
  }
} else {
  $sql="SELECT * FROM mapview";
}
    
try{
  $conn=new PDO(GBDSN,GBDBA,GBPWD);//use PDO objects, built in since PHP5
  $stmt1=$conn->prepare($sql);//statement object
  $stmt1->execute();//run statement
  $rows = array();
  if($stmt1->rowcount()==0){
    echo "failure";
  } else {
    while($rec=$stmt1->fetch(PDO::FETCH_ASSOC)){
	  $rows[] = $rec;
	}
	print json_encode($rows);
  }
  $rec = null;
  $stmt1=null;
  $conn=null;
}
			
catch(Exception $e){
  echo "failure";
}


?>