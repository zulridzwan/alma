-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 16, 2015 at 03:13 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `asnaflocator`
--

-- --------------------------------------------------------

--
-- Stand-in structure for view `mapview`
--
CREATE TABLE IF NOT EXISTS `mapview` (
`rowid` int(11)
,`reporterid` varchar(20)
,`reportername` varchar(255)
,`lat` double
,`lng` double
,`address` varchar(200)
,`town` varchar(100)
,`district` varchar(100)
,`state` varchar(100)
,`details` varchar(400)
,`filename` varchar(100)
,`email` varchar(255)
,`status` varchar(255)
);
-- --------------------------------------------------------

--
-- Table structure for table `reporter`
--

CREATE TABLE IF NOT EXISTS `reporter` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `reporterid` varchar(20) NOT NULL,
  `reportername` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  PRIMARY KEY (`rowid`),
  UNIQUE KEY `reporterid` (`reporterid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `reporterid` varchar(20) NOT NULL,
  `reportername` varchar(100) DEFAULT NULL,
  `emailaddress` varchar(100) DEFAULT NULL,
  `marker` point NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `town` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `details` varchar(400) NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'new',
  PRIMARY KEY (`rowid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

-- --------------------------------------------------------

--
-- Structure for view `mapview`
--
DROP TABLE IF EXISTS `mapview`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `mapview` AS select `b`.`rowid` AS `rowid`,`a`.`reporterid` AS `reporterid`,`a`.`reportername` AS `reportername`,st_x(`b`.`marker`) AS `lat`,st_y(`b`.`marker`) AS `lng`,`b`.`address` AS `address`,`b`.`town` AS `town`,`b`.`district` AS `district`,`b`.`state` AS `state`,`b`.`details` AS `details`,`b`.`filename` AS `filename`,`a`.`email` AS `email`,`b`.`status` AS `status` from (`reporter` `a` join `reports` `b`) where ((`a`.`reporterid` = `b`.`reporterid`) and (`b`.`status` = 'new'));

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
