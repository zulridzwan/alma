<?php
define('GBTITLE','Logistics Database System');
define('GBWEBSVR','localhost');
define('GBHOME','asnaflocator/');
define('JQUERYCSS','jquery-ui/css/gb/jquery-ui-1.8.16.custom.css');
define('JQUERYJSCORE','jquery-ui/js/jquery-1.6.2.min.js');
define('JQUERYJSUI','jquery-ui/js/jquery-ui-1.8.16.custom.min.js');
define('JQUERYPINEGRIDJS','pgrid-1.1.2/jquery.pgrid.min.js');
define('JQUERYPINEGRIDCSS','pgrid-1.1.2/jquery.pgrid.default.css');
define('JQUERYPINEGRIDICONCSS','pgrid-1.1.2/icons/jquery.pgrid.default.icons.css');
define('ICONSETCSS','img/icons.css');
//define('GOOGLEWEBFONTS','<link href=\'http://fonts.googleapis.com/css?family=Ubuntu:400,700\' rel=\'stylesheet\' type=\'text/css\'>');
define('GOOGLEWEBFONTS','');
?>