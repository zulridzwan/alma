<?php
include('includes/paths.php');
Header('Cache-Control: no-cache');//prevent ie from caching this page
Header('Pragma: no-cache');
header('Location:http://www.google.com');
?>