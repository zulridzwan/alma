<?php
include('includes/paths.php');
require('includes/credentials.php');
    $name       = $_FILES['uploadedfile']['name'];  
    $temp_name  = $_FILES['uploadedfile']['tmp_name'];  
	$reportername =$_POST['reportername'];
	$email =$_POST['email'];
	$details=$_POST['details'];
	$latitude=$_POST['latitude'];
	$longitude=$_POST['longitude'];
	$address=$_POST['address'];
	$town=$_POST['town'];
	$district=$_POST['district'];
	$state=$_POST['state'];
	$reporterphone=$_POST['reporterphone'];
	$filename="";
	
    if(isset($name)){
        if(!empty($name)){      
            $location = 'image/';      
            if(move_uploaded_file($temp_name, $location.$name)){
                echo 'success|';
				$filename=$location.$name;
            } else 
			{ echo 'failure|';
			}
        }       
    }  else {
        echo 'failure|';
    }
	
	if(isset($latitude)){
        if(!empty($latitude)){      
            //$file = fopen("test.txt","w");
            //fwrite($file,$reportername.",".$email.",".$details.",".$latitude.",".$longitude.",".$address.",".$town.",".$district.",".$state.",".$reporterphone);
            //fclose($file);
			
			try{
              $conn=new PDO(GBDSN,GBDBA,GBPWD);//use PDO objects, built in since PHP5
              $sql="SELECT * FROM reporter WHERE reporterid='".$reporterphone."'";
              $stmt1=$conn->prepare($sql);//statement object
              $stmt1->execute();//run statement
	
              if($stmt1->rowcount()==0){
			     $sql="INSERT INTO reporter (reporterid) VALUES ('".$reporterphone."')";
			     $stmt2=$conn->prepare($sql);//statement object
	             $conn->beginTransaction();//begin transaction
                 $stmt2->execute();//run statement
	             $conn->commit();
			  }
			  $stmt2=null;
			  
              $sql="INSERT INTO reports (reporterid, reportername, emailaddress, marker, address, town, district, state, details, filename) ".
			  " VALUES ('".str_replace("'","\'",$reporterphone)."','".str_replace("'","\'",$reportername)."','".str_replace("'","\'",$email).
	          "', GeomFromText('POINT(".$latitude." ".$longitude.")'), '".str_replace("'","\'",$address)."','".str_replace("'","\'",$town).
			  "','".str_replace("'","\'",$district)."','".str_replace("'","\'",$state)."','".str_replace("'","\'",$details)."','".str_replace("'","\'",$name).
	          "')";
	          $stmt3=$conn->prepare($sql);//statement object
	          $conn->beginTransaction();//begin transaction
              $stmt3->execute();//run statement
	          $conn->commit();
	  
	          if($stmt3->rowcount()>0){
                echo "success|";
	          } else {
	            echo "failure|";
	          }
			  $stmt1=null;
              $stmt3=null;
              $conn=null;
            }
			
			catch(Exception $e){
              if(isset($conn)){
                $conn->rollBack();
                $conn=null;
              }
            }       
        } else {
          echo 'failure|';
        }
    } else {
	    echo 'failure|';
    }


?>